# Top 5 Donation API Proxy

This is a simple proxy API to fetch top 5 donations and display them on your website.

## Setup

1. Clone this repository.
2. Deploy it on Vercel.
3. Add your API keys and other environment variables in Vercel settings.
    